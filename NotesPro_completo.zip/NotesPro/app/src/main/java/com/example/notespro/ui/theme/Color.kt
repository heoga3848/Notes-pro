package com.example.notespro.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

val PrimaryNeon = Color(0xFF00F2FF)
val SecondaryNeon = Color(0xFFFF00E5)

val DarkBackground = Color(0xFF0A0A0B)
val DarkSurface = Color(0xFF16161A)
val LightBackground = Color(0xFFEEF2F8)
val LightSurface = Color(0xFFFFFFFF)

// Variantes más oscuras para que el neón tenga contraste sobre fondo claro
val PrimaryNeonDark = Color(0xFF00A9B3)
val SecondaryNeonDark = Color(0xFFC800B5)

val NeonViolet = Color(0xFF8B5CF6)
val NeonBlue = Color(0xFF3B82F6)
val NeonGreen = Color(0xFF22C55E)
val NeonYellow = Color(0xFFFACC15)
val NeonOrange = Color(0xFFFB923C)
val NeonRed = Color(0xFFEF4444)

/** Paleta para carpetas (siempre tienen color). */
val FolderPaletteArgb: List<Int> = listOf(
    PrimaryNeon, SecondaryNeon, NeonViolet, NeonBlue,
    NeonGreen, NeonYellow, NeonOrange, NeonRed
).map { it.toArgb() }

/** Paleta para notas: 0 = sin color (cristal neutro). */
val NotePaletteArgb: List<Int> = listOf(0) + FolderPaletteArgb

fun Int.toColorOrNull(): Color? = if (this == 0) null else Color(this)

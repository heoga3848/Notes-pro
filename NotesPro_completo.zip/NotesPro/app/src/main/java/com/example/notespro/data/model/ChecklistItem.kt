package com.example.notespro.data.model

import org.json.JSONArray
import org.json.JSONObject

data class ChecklistItem(
    val id: Long,
    val text: String = "",
    val checked: Boolean = false
)

/** Serializa la checklist a JSON para guardarla en una sola columna de Room. */
object ChecklistCodec {

    fun encode(items: List<ChecklistItem>): String {
        val array = JSONArray()
        items.forEach { item ->
            array.put(
                JSONObject()
                    .put("id", item.id)
                    .put("text", item.text)
                    .put("checked", item.checked)
            )
        }
        return array.toString()
    }

    fun decode(json: String): List<ChecklistItem> {
        if (json.isBlank()) return emptyList()
        return try {
            val array = JSONArray(json)
            List(array.length()) { index ->
                val obj = array.getJSONObject(index)
                ChecklistItem(
                    id = obj.optLong("id", index.toLong()),
                    text = obj.optString("text", ""),
                    checked = obj.optBoolean("checked", false)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

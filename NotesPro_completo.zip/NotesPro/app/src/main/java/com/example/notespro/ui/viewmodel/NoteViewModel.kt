package com.example.notespro.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.notespro.data.model.ChecklistCodec
import com.example.notespro.data.model.ChecklistItem
import com.example.notespro.data.model.FolderEntity
import com.example.notespro.data.model.NoteEntity
import com.example.notespro.domain.repository.NoteRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Estado de la pantalla Home. */
data class HomeUiState(
    val pinned: List<NoteEntity> = emptyList(),
    val others: List<NoteEntity> = emptyList(),
    val folders: List<FolderEntity> = emptyList(),
    val selectedFolderId: Long? = null,
    val totalNotes: Int = 0
)

/** Borrador de la nota que se está editando. */
data class EditorState(
    val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val checklist: List<ChecklistItem> = emptyList(),
    val colorArgb: Int = 0,
    val isPinned: Boolean = false,
    val isPrivate: Boolean = false,
    val folderId: Long? = null,
    val createdAt: Long = 0L,
    /** Identifica la sesión de edición; descarta guardados de notas ya cerradas o borradas. */
    val session: Int = 0
) {
    val isBlank: Boolean
        get() = title.isBlank() && content.isBlank() && checklist.none { it.text.isNotBlank() }
}

@OptIn(FlowPreview::class)
class NoteViewModel(private val repository: NoteRepository) : ViewModel() {

    // ---------------------------------------------------------------- HOME

    private val _query = MutableStateFlow("")
    /** Se expone aparte (no dentro de HomeUiState) para que el TextField no pierda el cursor. */
    val query: StateFlow<String> = _query.asStateFlow()

    private val _selectedFolderId = MutableStateFlow<Long?>(null)

    val folders: StateFlow<List<FolderEntity>> = repository.observeFolders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val uiState: StateFlow<HomeUiState> = combine(
        repository.observeNotes(),
        repository.observeFolders(),
        _query,
        _selectedFolderId
    ) { notes, folders, rawQuery, folderId ->
        val q = rawQuery.trim()
        val filtered = notes.filter { note ->
            val inFolder = folderId == null || note.folderId == folderId
            // En notas privadas solo se busca por título: su contenido no debe filtrarse.
            val matches = q.isEmpty() ||
                note.title.contains(q, ignoreCase = true) ||
                (!note.isPrivate && (
                    note.content.contains(q, ignoreCase = true) ||
                        note.checklistItems().any { it.text.contains(q, ignoreCase = true) }
                    ))
            inFolder && matches
        }
        HomeUiState(
            pinned = filtered.filter { it.isPinned },
            others = filtered.filter { !it.isPinned },
            folders = folders,
            selectedFolderId = folderId,
            totalNotes = notes.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    fun onQueryChange(value: String) {
        _query.value = value
    }

    fun selectFolder(id: Long?) {
        _selectedFolderId.value = id
    }

    fun togglePin(note: NoteEntity) {
        viewModelScope.launch { repository.setPinned(note.id, !note.isPinned) }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch { repository.deleteNote(note.id) }
    }

    /** Deshacer eliminación: reinserta la nota con su mismo id. */
    fun restoreNote(note: NoteEntity) {
        viewModelScope.launch { repository.saveNote(note) }
    }

    fun saveFolder(folder: FolderEntity) {
        viewModelScope.launch { repository.saveFolder(folder) }
    }

    fun deleteFolder(id: Long) {
        if (_selectedFolderId.value == id) _selectedFolderId.value = null
        viewModelScope.launch { repository.deleteFolder(id) }
    }

    // -------------------------------------------------------------- EDITOR

    private val _editor = MutableStateFlow(EditorState())
    val editor: StateFlow<EditorState> = _editor.asStateFlow()

    private var session = 0
    private var editingKey: Long? = null
    @Volatile private var dirty = false
    private val saveMutex = Mutex()

    private val saveRequests = MutableSharedFlow<EditorState>(
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    init {
        // Autoguardado: se guarda cuando pasan 500 ms sin escribir.
        viewModelScope.launch {
            saveRequests.debounce(AUTOSAVE_DELAY_MS).collect { persist(it) }
        }
    }

    /** noteId = 0 crea una nota nueva. Es idempotente (rotación de pantalla). */
    fun beginEditing(noteId: Long) {
        if (editingKey == noteId) return
        editingKey = noteId
        session++
        dirty = false
        val currentSession = session
        _editor.value = EditorState(
            session = currentSession,
            folderId = if (noteId == 0L) _selectedFolderId.value else null
        )
        if (noteId != 0L) {
            viewModelScope.launch {
                val note = repository.getNote(noteId)
                if (note != null && currentSession == session) {
                    _editor.value = note.toEditorState(currentSession)
                }
            }
        }
    }

    fun endEditing() {
        editingKey = null
    }

    /** Guarda inmediatamente si hay cambios pendientes (al salir del editor). */
    fun flush() {
        if (!dirty) return
        val snapshot = _editor.value
        viewModelScope.launch { persist(snapshot) }
    }

    fun onTitleChange(value: String) = edit { it.copy(title = value) }
    fun onContentChange(value: String) = edit { it.copy(content = value) }
    fun onColorChange(argb: Int) = edit { it.copy(colorArgb = argb) }
    fun onFolderChange(folderId: Long?) = edit { it.copy(folderId = folderId) }
    fun togglePinned() = edit { it.copy(isPinned = !it.isPinned) }
    fun setPrivate(value: Boolean) = edit { it.copy(isPrivate = value) }

    fun addChecklistItem() = edit { state ->
        val nextId = (state.checklist.maxOfOrNull { it.id } ?: 0L) + 1
        state.copy(checklist = state.checklist + ChecklistItem(id = nextId))
    }

    fun onChecklistTextChange(itemId: Long, text: String) = edit { state ->
        state.copy(checklist = state.checklist.map { if (it.id == itemId) it.copy(text = text) else it })
    }

    fun toggleChecklistItem(itemId: Long) = edit { state ->
        state.copy(checklist = state.checklist.map { if (it.id == itemId) it.copy(checked = !it.checked) else it })
    }

    fun removeChecklistItem(itemId: Long) = edit { state ->
        state.copy(checklist = state.checklist.filterNot { it.id == itemId })
    }

    fun deleteCurrentNote(onDone: () -> Unit) {
        viewModelScope.launch {
            saveMutex.withLock {
                val id = _editor.value.id
                session++ // invalida cualquier guardado pendiente de esta nota
                dirty = false
                _editor.value = EditorState(session = session)
                if (id != 0L) repository.deleteNote(id)
            }
            onDone()
        }
    }

    private fun edit(transform: (EditorState) -> EditorState) {
        val updated = transform(_editor.value)
        _editor.value = updated
        dirty = true
        saveRequests.tryEmit(updated)
    }

    private suspend fun persist(snapshot: EditorState) {
        saveMutex.withLock {
            if (snapshot.session != session) return
            val id = if (snapshot.id != 0L) snapshot.id else _editor.value.id
            if (id == 0L && snapshot.isBlank) return // no se guardan notas nuevas vacías

            dirty = false
            val now = System.currentTimeMillis()
            val createdAt = snapshot.createdAt.takeIf { it != 0L }
                ?: _editor.value.createdAt.takeIf { it != 0L }
                ?: now

            val savedId = repository.saveNote(
                NoteEntity(
                    id = id,
                    title = snapshot.title,
                    content = snapshot.content,
                    checklistJson = ChecklistCodec.encode(snapshot.checklist),
                    colorArgb = snapshot.colorArgb,
                    isPinned = snapshot.isPinned,
                    isPrivate = snapshot.isPrivate,
                    folderId = snapshot.folderId,
                    createdAt = createdAt,
                    updatedAt = now
                )
            )
            if (snapshot.session == session) {
                _editor.update { if (it.id == 0L) it.copy(id = savedId, createdAt = createdAt) else it }
            }
        }
    }

    private fun NoteEntity.toEditorState(sessionId: Int) = EditorState(
        id = id,
        title = title,
        content = content,
        checklist = checklistItems(),
        colorArgb = colorArgb,
        isPinned = isPinned,
        isPrivate = isPrivate,
        folderId = folderId,
        createdAt = createdAt,
        session = sessionId
    )

    class Factory(private val repository: NoteRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            NoteViewModel(repository) as T
    }

    private companion object {
        const val AUTOSAVE_DELAY_MS = 500L
    }
}

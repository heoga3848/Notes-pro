package com.example.notespro.domain.repository

import com.example.notespro.data.model.FolderEntity
import com.example.notespro.data.model.NoteEntity
import kotlinx.coroutines.flow.Flow

interface NoteRepository {
    fun observeNotes(): Flow<List<NoteEntity>>
    fun observeFolders(): Flow<List<FolderEntity>>

    suspend fun getNote(id: Long): NoteEntity?
    /** Devuelve el id de la nota guardada (nuevo o existente). */
    suspend fun saveNote(note: NoteEntity): Long
    suspend fun setPinned(id: Long, pinned: Boolean)
    suspend fun deleteNote(id: Long)

    suspend fun saveFolder(folder: FolderEntity): Long
    suspend fun deleteFolder(id: Long)
}

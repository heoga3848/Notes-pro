package com.example.notespro

import android.app.Application
import com.example.notespro.data.database.AppDatabase
import com.example.notespro.data.repository.NoteRepositoryImpl
import com.example.notespro.domain.repository.NoteRepository

class NotesProApp : Application() {

    private val database by lazy { AppDatabase.getInstance(this) }

    val repository: NoteRepository by lazy {
        NoteRepositoryImpl(database.noteDao(), database.folderDao())
    }
}

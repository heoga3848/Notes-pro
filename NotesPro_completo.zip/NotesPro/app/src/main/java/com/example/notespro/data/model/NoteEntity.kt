package com.example.notespro.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "notes",
    foreignKeys = [
        ForeignKey(
            entity = FolderEntity::class,
            parentColumns = ["id"],
            childColumns = ["folderId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("folderId")]
)
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val content: String = "",
    /** Checklist serializada como JSON (ver ChecklistCodec). */
    val checklistJson: String = "[]",
    /** Color ARGB; 0 = color por defecto (cristal neutro). */
    val colorArgb: Int = 0,
    val isPinned: Boolean = false,
    val isPrivate: Boolean = false,
    val folderId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun checklistItems(): List<ChecklistItem> = ChecklistCodec.decode(checklistJson)
}

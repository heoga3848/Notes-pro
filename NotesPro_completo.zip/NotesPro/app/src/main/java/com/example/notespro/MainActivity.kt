package com.example.notespro

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.notespro.ui.screens.HomeScreen
import com.example.notespro.ui.screens.NoteEditorScreen
import com.example.notespro.ui.theme.NotesProTheme
import com.example.notespro.ui.viewmodel.NoteViewModel

object Routes {
    const val HOME = "home"
    const val EDITOR = "editor/{noteId}"
    fun editor(noteId: Long) = "editor/$noteId"
}

// FragmentActivity (y no solo ComponentActivity) es obligatorio para BiometricPrompt.
class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = (application as NotesProApp).repository

        setContent {
            val systemDark = isSystemInDarkTheme()
            val prefs = remember { getSharedPreferences("settings", MODE_PRIVATE) }
            var isDark by rememberSaveable { mutableStateOf(prefs.getBoolean("dark", systemDark)) }

            NotesProTheme(darkTheme = isDark) {
                val navController = rememberNavController()
                val viewModel: NoteViewModel = viewModel(factory = NoteViewModel.Factory(repository))

                NavHost(navController = navController, startDestination = Routes.HOME) {
                    composable(Routes.HOME) {
                        HomeScreen(
                            viewModel = viewModel,
                            isDark = isDark,
                            onToggleTheme = {
                                isDark = !isDark
                                prefs.edit().putBoolean("dark", isDark).apply()
                            },
                            onOpenNote = { id -> navController.navigate(Routes.editor(id)) },
                            onNewNote = { navController.navigate(Routes.editor(0L)) }
                        )
                    }
                    composable(
                        route = Routes.EDITOR,
                        arguments = listOf(navArgument("noteId") { type = NavType.LongType })
                    ) { entry ->
                        val noteId = entry.arguments?.getLong("noteId") ?: 0L
                        NoteEditorScreen(
                            viewModel = viewModel,
                            noteId = noteId,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}

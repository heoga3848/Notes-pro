package com.example.notespro.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.notespro.ui.theme.LocalIsDark
import com.example.notespro.ui.theme.PrimaryNeon
import com.example.notespro.ui.theme.SecondaryNeon

/**
 * Tarjeta "Liquid Glass": relleno translúcido con degradado, borde brillante
 * con gradiente y esquinas redondeadas (24dp por defecto).
 * [tint] colorea el cristal (color de la nota o carpeta).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    tint: Color? = null,
    cornerRadius: Dp = 24.dp,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val isDark = LocalIsDark.current
    val shape = RoundedCornerShape(cornerRadius)

    val fill = when {
        tint != null -> Brush.verticalGradient(
            listOf(
                tint.copy(alpha = if (isDark) 0.30f else 0.38f),
                tint.copy(alpha = if (isDark) 0.10f else 0.16f)
            )
        )
        isDark -> Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.04f))
        )
        else -> Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.80f), Color.White.copy(alpha = 0.50f))
        )
    }

    val border = Brush.linearGradient(
        listOf(
            Color.White.copy(alpha = if (isDark) 0.55f else 0.95f),
            (tint ?: PrimaryNeon).copy(alpha = 0.18f),
            (tint ?: SecondaryNeon).copy(alpha = 0.50f)
        )
    )

    val clickModifier =
        if (onClick != null || onLongClick != null) {
            Modifier.combinedClickable(
                onClick = { onClick?.invoke() },
                onLongClick = onLongClick
            )
        } else {
            Modifier
        }

    Column(
        modifier = modifier
            .clip(shape)
            .background(fill)
            .border(1.dp, border, shape)
            .then(clickModifier)
            .padding(contentPadding),
        content = content
    )
}

/**
 * Fondo profundo con "orbes" de neón difuminados. Los orbes dan a las tarjetas
 * translúcidas algo que refractar, que es lo que produce el efecto cristal.
 */
@Composable
fun GlassBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = LocalIsDark.current
    val base = MaterialTheme.colorScheme.background
    val orbAlpha = if (isDark) 0.30f else 0.22f

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(base)
            .drawBehind {
                val radius = size.maxDimension * 0.55f
                fun orb(color: Color, cx: Float, cy: Float) {
                    val center = Offset(cx, cy)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(color.copy(alpha = orbAlpha), Color.Transparent),
                            center = center,
                            radius = radius
                        ),
                        radius = radius,
                        center = center
                    )
                }
                orb(PrimaryNeon, size.width * 0.10f, size.height * 0.08f)
                orb(SecondaryNeon, size.width * 0.95f, size.height * 0.50f)
                orb(Color(0xFF8B5CF6), size.width * 0.15f, size.height * 0.95f)
            }
    ) {
        CompositionLocalProvider(
            LocalContentColor provides MaterialTheme.colorScheme.onBackground
        ) {
            content()
        }
    }
}

/** Botón flotante "+" con gradiente neón, borde brillante y resplandor. */
@Composable
fun GlassFab(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(64.dp)
            .shadow(
                elevation = 16.dp,
                shape = CircleShape,
                ambientColor = PrimaryNeon,
                spotColor = SecondaryNeon
            )
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(PrimaryNeon, SecondaryNeon)))
            .border(
                1.5.dp,
                Brush.linearGradient(
                    listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0.1f))
                ),
                CircleShape
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "Nueva nota",
            tint = Color.Black,
            modifier = Modifier.size(30.dp)
        )
    }
}

/** Colores de TextField transparentes para usarlos dentro de una tarjeta de cristal. */
@Composable
fun glassTextFieldColors(): TextFieldColors = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent,
    unfocusedContainerColor = Color.Transparent,
    disabledContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent,
    unfocusedIndicatorColor = Color.Transparent,
    disabledIndicatorColor = Color.Transparent,
    cursorColor = PrimaryNeon
)

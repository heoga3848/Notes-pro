package com.example.notespro.ui.screens

import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.notespro.data.model.FolderEntity
import com.example.notespro.data.model.NoteEntity
import com.example.notespro.ui.components.ColorPicker
import com.example.notespro.ui.components.FolderChip
import com.example.notespro.ui.components.GlassBackground
import com.example.notespro.ui.components.GlassFab
import com.example.notespro.ui.components.LiquidGlassCard
import com.example.notespro.ui.components.glassTextFieldColors
import com.example.notespro.ui.theme.FolderPaletteArgb
import com.example.notespro.ui.theme.PrimaryNeon
import com.example.notespro.ui.theme.SecondaryNeon
import com.example.notespro.ui.theme.toColorOrNull
import com.example.notespro.ui.viewmodel.NoteViewModel
import com.example.notespro.util.BiometricHelper
import com.example.notespro.util.findFragmentActivity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    viewModel: NoteViewModel,
    isDark: Boolean,
    onToggleTheme: () -> Unit,
    onOpenNote: (Long) -> Unit,
    onNewNote: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val activity = remember(context) { context.findFragmentActivity() }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var showFolderDialog by remember { mutableStateOf(false) }
    var editingFolder by remember { mutableStateOf<FolderEntity?>(null) }
    var folderToDelete by remember { mutableStateOf<FolderEntity?>(null) }
    var folderMenuId by remember { mutableStateOf<Long?>(null) }

    val foldersById = remember(state.folders) { state.folders.associateBy { it.id } }
    val fullSpan: LazyGridItemSpanScope.() -> GridItemSpan = { GridItemSpan(maxLineSpan) }

    /** Ejecuta [action]; si la nota es privada, exige huella / PIN del dispositivo antes. */
    fun unlock(note: NoteEntity, action: () -> Unit) {
        if (!note.isPrivate) {
            action()
            return
        }
        if (activity == null || !BiometricHelper.canAuthenticate(context)) {
            Toast.makeText(
                context,
                "Configura un PIN, patrón o huella en los ajustes del dispositivo para abrir notas privadas",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        BiometricHelper.authenticate(
            activity = activity,
            title = "Nota privada",
            subtitle = "Autentícate para continuar",
            onSuccess = action,
            onError = { message -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show() }
        )
    }

    fun deleteNote(note: NoteEntity) = unlock(note) {
        viewModel.deleteNote(note)
        scope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            val result = snackbarHostState.showSnackbar(
                message = "Nota eliminada",
                actionLabel = "Deshacer",
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) viewModel.restoreNote(note)
        }
    }

    GlassBackground {
        Scaffold(
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onBackground,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            floatingActionButton = { GlassFab(onClick = onNewNote) }
        ) { padding ->
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = padding.calculateTopPadding() + 8.dp,
                    bottom = padding.calculateBottomPadding() + 96.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ---------- Cabecera: título, búsqueda y carpetas ----------
                item(key = "header", span = fullSpan) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    text = "NotesPro",
                                    style = MaterialTheme.typography.displaySmall.copy(
                                        brush = Brush.horizontalGradient(
                                            listOf(PrimaryNeon, SecondaryNeon)
                                        )
                                    )
                                )
                                Text(
                                    text = "${state.totalNotes} notas",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                )
                            }
                            IconButton(onClick = onToggleTheme) {
                                Icon(
                                    imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                    contentDescription = "Cambiar tema"
                                )
                            }
                        }

                        Spacer(Modifier.height(12.dp))

                        LiquidGlassCard(Modifier.fillMaxWidth()) {
                            TextField(
                                value = query,
                                onValueChange = viewModel::onQueryChange,
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Buscar en títulos y contenido") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                trailingIcon = {
                                    if (query.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.onQueryChange("") }) {
                                            Icon(Icons.Default.Close, contentDescription = "Borrar búsqueda")
                                        }
                                    }
                                },
                                singleLine = true,
                                colors = glassTextFieldColors()
                            )
                        }

                        Spacer(Modifier.height(12.dp))

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            item(key = "chip_all") {
                                FolderChip(
                                    label = "Todas",
                                    color = null,
                                    selected = state.selectedFolderId == null,
                                    onClick = { viewModel.selectFolder(null) }
                                )
                            }
                            items(state.folders, key = { "chip_${it.id}" }) { folder ->
                                Box {
                                    FolderChip(
                                        label = folder.name,
                                        color = Color(folder.colorArgb),
                                        selected = state.selectedFolderId == folder.id,
                                        onClick = { viewModel.selectFolder(folder.id) },
                                        onLongClick = { folderMenuId = folder.id }
                                    )
                                    DropdownMenu(
                                        expanded = folderMenuId == folder.id,
                                        onDismissRequest = { folderMenuId = null }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("Editar carpeta") },
                                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                                            onClick = {
                                                folderMenuId = null
                                                editingFolder = folder
                                                showFolderDialog = true
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Eliminar carpeta") },
                                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                                            onClick = {
                                                folderMenuId = null
                                                folderToDelete = folder
                                            }
                                        )
                                    }
                                }
                            }
                            item(key = "chip_add") {
                                FolderChip(
                                    label = "Carpeta",
                                    color = null,
                                    selected = false,
                                    leadingIcon = Icons.Default.CreateNewFolder,
                                    onClick = {
                                        editingFolder = null
                                        showFolderDialog = true
                                    }
                                )
                            }
                        }
                    }
                }

                // ---------- Estado vacío ----------
                if (state.pinned.isEmpty() && state.others.isEmpty()) {
                    item(key = "empty", span = fullSpan) {
                        EmptyState(hasQuery = query.isNotBlank())
                    }
                }

                // ---------- Notas fijadas ----------
                if (state.pinned.isNotEmpty()) {
                    item(key = "pinned_label", span = fullSpan) {
                        SectionLabel(text = "FIJADAS", icon = Icons.Default.PushPin)
                    }
                    items(state.pinned, key = { "note_${it.id}" }) { note ->
                        NoteCard(
                            note = note,
                            folder = note.folderId?.let { foldersById[it] },
                            onClick = { unlock(note) { onOpenNote(note.id) } },
                            onTogglePin = { viewModel.togglePin(note) },
                            onDelete = { deleteNote(note) }
                        )
                    }
                }

                // ---------- Resto de notas ----------
                if (state.others.isNotEmpty()) {
                    if (state.pinned.isNotEmpty()) {
                        item(key = "others_label", span = fullSpan) {
                            SectionLabel(text = "OTRAS")
                        }
                    }
                    items(state.others, key = { "note_${it.id}" }) { note ->
                        NoteCard(
                            note = note,
                            folder = note.folderId?.let { foldersById[it] },
                            onClick = { unlock(note) { onOpenNote(note.id) } },
                            onTogglePin = { viewModel.togglePin(note) },
                            onDelete = { deleteNote(note) }
                        )
                    }
                }
            }
        }

        // ---------- Diálogos de carpeta ----------
        if (showFolderDialog) {
            FolderDialog(
                initial = editingFolder,
                onDismiss = { showFolderDialog = false },
                onConfirm = { name, color ->
                    val base = editingFolder ?: FolderEntity(name = "", colorArgb = color)
                    viewModel.saveFolder(base.copy(name = name.trim(), colorArgb = color))
                    showFolderDialog = false
                }
            )
        }

        folderToDelete?.let { folder ->
            AlertDialog(
                onDismissRequest = { folderToDelete = null },
                title = { Text("Eliminar carpeta") },
                text = {
                    Text("Se eliminará «${folder.name}». Las notas que contiene se conservarán sin carpeta.")
                },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.deleteFolder(folder.id)
                        folderToDelete = null
                    }) { Text("Eliminar") }
                },
                dismissButton = {
                    TextButton(onClick = { folderToDelete = null }) { Text("Cancelar") }
                }
            )
        }
    }
}

@Composable
private fun SectionLabel(text: String, icon: ImageVector? = null) {
    Row(
        modifier = Modifier.padding(top = 4.dp, start = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = PrimaryNeon,
                modifier = Modifier.size(14.dp)
            )
            Spacer(Modifier.width(6.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )
    }
}

@Composable
private fun EmptyState(hasQuery: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 64.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = if (hasQuery) Icons.Default.Search else Icons.Default.Edit,
            contentDescription = null,
            modifier = Modifier
                .size(48.dp)
                .alpha(0.4f)
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = if (hasQuery) "Sin resultados" else "Aún no hay notas.\nToca + para crear la primera.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            textAlign = TextAlign.Center
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NoteCard(
    note: NoteEntity,
    folder: FolderEntity?,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val checklist = remember(note.checklistJson, note.isPrivate) {
        if (note.isPrivate) emptyList() else note.checklistItems()
    }
    val dateFormat = remember { SimpleDateFormat("d MMM", Locale.getDefault()) }
    val bodyColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)

    Box {
        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            tint = note.colorArgb.toColorOrNull(),
            contentPadding = PaddingValues(16.dp),
            onClick = onClick,
            onLongClick = { menuOpen = true }
        ) {
            Row(verticalAlignment = Alignment.Top) {
                Text(
                    text = note.title.ifBlank { "Sin título" },
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (note.isPinned) {
                    Icon(
                        imageVector = Icons.Default.PushPin,
                        contentDescription = "Fijada",
                        tint = PrimaryNeon,
                        modifier = Modifier
                            .padding(start = 4.dp)
                            .size(16.dp)
                    )
                }
                if (note.isPrivate) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Privada",
                        tint = SecondaryNeon,
                        modifier = Modifier
                            .padding(start = 4.dp)
                            .size(16.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            if (note.isPrivate) {
                Text(
                    text = "Contenido protegido",
                    style = MaterialTheme.typography.bodyMedium,
                    fontStyle = FontStyle.Italic,
                    color = bodyColor
                )
            } else {
                if (note.content.isNotBlank()) {
                    Text(
                        text = note.content,
                        style = MaterialTheme.typography.bodyMedium,
                        color = bodyColor,
                        maxLines = 6,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                checklist.take(3).forEach { item ->
                    Row(
                        modifier = Modifier.padding(top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (item.checked) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                            contentDescription = null,
                            tint = if (item.checked) PrimaryNeon else bodyColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = item.text.ifBlank { "…" },
                            style = MaterialTheme.typography.bodyMedium,
                            color = bodyColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textDecoration = if (item.checked) TextDecoration.LineThrough else TextDecoration.None
                        )
                    }
                }
                if (checklist.size > 3) {
                    Text(
                        text = "+${checklist.size - 3} más",
                        style = MaterialTheme.typography.labelSmall,
                        color = bodyColor,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (folder != null) {
                    Box(
                        Modifier
                            .size(8.dp)
                            .background(Color(folder.colorArgb), CircleShape)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = folder.name,
                        style = MaterialTheme.typography.labelSmall,
                        color = bodyColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Spacer(Modifier.weight(1f))
                }
                Text(
                    text = dateFormat.format(Date(note.updatedAt)),
                    style = MaterialTheme.typography.labelSmall,
                    color = bodyColor
                )
            }
        }

        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(
                text = { Text(if (note.isPinned) "Desfijar" else "Fijar arriba") },
                leadingIcon = { Icon(Icons.Default.PushPin, null) },
                onClick = {
                    menuOpen = false
                    onTogglePin()
                }
            )
            DropdownMenuItem(
                text = { Text("Eliminar") },
                leadingIcon = { Icon(Icons.Default.Delete, null) },
                onClick = {
                    menuOpen = false
                    onDelete()
                }
            )
        }
    }
}

@Composable
private fun FolderDialog(
    initial: FolderEntity?,
    onDismiss: () -> Unit,
    onConfirm: (name: String, colorArgb: Int) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var color by remember { mutableIntStateOf(initial?.colorArgb ?: PrimaryNeon.toArgb()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nueva carpeta" else "Editar carpeta") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Text("Color", style = MaterialTheme.typography.labelLarge)
                ColorPicker(
                    selectedArgb = color,
                    options = FolderPaletteArgb,
                    onSelect = { color = it }
                )
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onConfirm(name, color) }) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

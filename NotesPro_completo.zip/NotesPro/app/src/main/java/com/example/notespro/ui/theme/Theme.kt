package com.example.notespro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.notespro.util.findActivity

/** Permite a los componentes de cristal saber si el tema activo es oscuro. */
val LocalIsDark = staticCompositionLocalOf { true }

private val DarkColors = darkColorScheme(
    primary = PrimaryNeon,
    onPrimary = Color.Black,
    secondary = SecondaryNeon,
    onSecondary = Color.White,
    background = DarkBackground,
    onBackground = Color.White,
    surface = DarkSurface,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF22222A),
    onSurfaceVariant = Color(0xFFB4B7C0),
    outline = Color(0xFF3A3A44)
)

private val LightColors = lightColorScheme(
    primary = PrimaryNeonDark,
    onPrimary = Color.White,
    secondary = SecondaryNeonDark,
    onSecondary = Color.White,
    background = LightBackground,
    onBackground = Color(0xFF0A0A0B),
    surface = LightSurface,
    onSurface = Color(0xFF0A0A0B),
    surfaceVariant = Color(0xFFE3E8F0),
    onSurfaceVariant = Color(0xFF4A4F5C),
    outline = Color(0xFFB8BECB)
)

@Composable
fun NotesProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !darkTheme
                controller.isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(LocalIsDark provides darkTheme) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

package com.example.notespro.data.repository

import com.example.notespro.data.dao.FolderDao
import com.example.notespro.data.dao.NoteDao
import com.example.notespro.data.model.FolderEntity
import com.example.notespro.data.model.NoteEntity
import com.example.notespro.domain.repository.NoteRepository
import kotlinx.coroutines.flow.Flow

class NoteRepositoryImpl(
    private val noteDao: NoteDao,
    private val folderDao: FolderDao
) : NoteRepository {

    override fun observeNotes(): Flow<List<NoteEntity>> = noteDao.observeAll()

    override fun observeFolders(): Flow<List<FolderEntity>> = folderDao.observeAll()

    override suspend fun getNote(id: Long): NoteEntity? = noteDao.getById(id)

    override suspend fun saveNote(note: NoteEntity): Long = noteDao.upsert(note)

    override suspend fun setPinned(id: Long, pinned: Boolean) = noteDao.setPinned(id, pinned)

    override suspend fun deleteNote(id: Long) = noteDao.deleteById(id)

    override suspend fun saveFolder(folder: FolderEntity): Long =
        if (folder.id == 0L) {
            folderDao.insert(folder)
        } else {
            folderDao.update(folder)
            folder.id
        }

    override suspend fun deleteFolder(id: Long) = folderDao.deleteById(id)
}

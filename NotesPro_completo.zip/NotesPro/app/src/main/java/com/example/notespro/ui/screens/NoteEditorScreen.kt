package com.example.notespro.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.notespro.ui.components.ColorPicker
import com.example.notespro.ui.components.FolderChip
import com.example.notespro.ui.components.GlassBackground
import com.example.notespro.ui.components.LiquidGlassCard
import com.example.notespro.ui.components.glassTextFieldColors
import com.example.notespro.ui.theme.NotePaletteArgb
import com.example.notespro.ui.theme.PrimaryNeon
import com.example.notespro.ui.theme.SecondaryNeon
import com.example.notespro.ui.theme.toColorOrNull
import com.example.notespro.ui.viewmodel.NoteViewModel
import com.example.notespro.util.BiometricHelper
import com.example.notespro.util.findActivity

@Composable
fun NoteEditorScreen(
    viewModel: NoteViewModel,
    noteId: Long,
    onBack: () -> Unit
) {
    val state by viewModel.editor.collectAsStateWithLifecycle()
    val folders by viewModel.folders.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showDeleteDialog by remember { mutableStateOf(false) }

    LaunchedEffect(noteId) { viewModel.beginEditing(noteId) }

    DisposableEffect(Unit) {
        onDispose {
            viewModel.flush()
            // En rotación de pantalla se conserva la sesión de edición.
            val rotating = context.findActivity()?.isChangingConfigurations == true
            if (!rotating) viewModel.endEditing()
        }
    }

    val onSurfaceMuted = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)

    GlassBackground {
        Scaffold(
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onBackground
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .consumeWindowInsets(padding)
                    .imePadding()
            ) {
                // ---------------- Barra superior ----------------
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                    Spacer(Modifier.weight(1f))

                    IconButton(onClick = viewModel::togglePinned) {
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = if (state.isPinned) "Desfijar" else "Fijar",
                            tint = if (state.isPinned) PrimaryNeon else MaterialTheme.colorScheme.onBackground
                        )
                    }
                    IconButton(onClick = {
                        if (state.isPrivate) {
                            viewModel.setPrivate(false)
                        } else if (BiometricHelper.canAuthenticate(context)) {
                            viewModel.setPrivate(true)
                        } else {
                            Toast.makeText(
                                context,
                                "Configura un PIN, patrón o huella en los ajustes del dispositivo para usar notas privadas",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }) {
                        Icon(
                            imageVector = if (state.isPrivate) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = if (state.isPrivate) "Quitar bloqueo" else "Bloquear nota",
                            tint = if (state.isPrivate) SecondaryNeon else MaterialTheme.colorScheme.onBackground
                        )
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Eliminar nota")
                    }
                }

                // ---------------- Contenido ----------------
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        tint = state.colorArgb.toColorOrNull()
                    ) {
                        TextField(
                            value = state.title,
                            onValueChange = viewModel::onTitleChange,
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Título", style = MaterialTheme.typography.titleLarge) },
                            textStyle = MaterialTheme.typography.titleLarge,
                            maxLines = 3,
                            colors = glassTextFieldColors()
                        )
                        TextField(
                            value = state.content,
                            onValueChange = viewModel::onContentChange,
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Escribe tu nota…") },
                            textStyle = MaterialTheme.typography.bodyLarge,
                            minLines = 8,
                            colors = glassTextFieldColors()
                        )
                    }

                    // Lista de tareas
                    Text("LISTA DE TAREAS", style = MaterialTheme.typography.labelSmall, color = onSurfaceMuted)
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp)
                    ) {
                        for (item in state.checklist) {
                            key(item.id) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = item.checked,
                                        onCheckedChange = { viewModel.toggleChecklistItem(item.id) },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = PrimaryNeon,
                                            checkmarkColor = Color.Black
                                        )
                                    )
                                    TextField(
                                        value = item.text,
                                        onValueChange = { viewModel.onChecklistTextChange(item.id, it) },
                                        modifier = Modifier.weight(1f),
                                        placeholder = { Text("Elemento") },
                                        singleLine = true,
                                        textStyle = LocalTextStyle.current.copy(
                                            textDecoration = if (item.checked) TextDecoration.LineThrough else TextDecoration.None
                                        ),
                                        colors = glassTextFieldColors()
                                    )
                                    IconButton(onClick = { viewModel.removeChecklistItem(item.id) }) {
                                        Icon(Icons.Default.Close, contentDescription = "Quitar elemento")
                                    }
                                }
                            }
                        }
                        TextButton(onClick = viewModel::addChecklistItem) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Añadir elemento")
                        }
                    }

                    // Carpeta
                    Text("CARPETA", style = MaterialTheme.typography.labelSmall, color = onSurfaceMuted)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item(key = "no_folder") {
                            FolderChip(
                                label = "Sin carpeta",
                                color = null,
                                selected = state.folderId == null,
                                onClick = { viewModel.onFolderChange(null) }
                            )
                        }
                        items(folders, key = { it.id }) { folder ->
                            FolderChip(
                                label = folder.name,
                                color = Color(folder.colorArgb),
                                selected = state.folderId == folder.id,
                                onClick = { viewModel.onFolderChange(folder.id) }
                            )
                        }
                    }

                    // Color
                    Text("COLOR", style = MaterialTheme.typography.labelSmall, color = onSurfaceMuted)
                    ColorPicker(
                        selectedArgb = state.colorArgb,
                        options = NotePaletteArgb,
                        onSelect = viewModel::onColorChange
                    )

                    Spacer(Modifier.height(24.dp))
                }
            }
        }

        if (showDeleteDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteDialog = false },
                title = { Text("Eliminar nota") },
                text = { Text("Esta acción no se puede deshacer.") },
                confirmButton = {
                    TextButton(onClick = {
                        showDeleteDialog = false
                        viewModel.deleteCurrentNote(onDone = onBack)
                    }) { Text("Eliminar") }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteDialog = false }) { Text("Cancelar") }
                }
            )
        }
    }
}
